cellSound = love.audio.newSource("gfx/sound/cell.ogg", "static")
virusSound = love.audio.newSource("gfx/sound/virus.ogg", "static")