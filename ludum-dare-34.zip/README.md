Ludum Dare 34
=============

TODO: A proper readme ;P

Todo Priority List:
===
1. Units
	1.1 Virus Units
		1.1.1 Movable
			1.1.1.1 Actions
		1.1.2 Stationary
	1.2 ImmuneSystem Units
		1.1.1 Movable
			1.1.1.1 Actions
	1.3 Selecting
	1.4 AI
2. Shop
3. Main Menu
4. Endgame
