return {{"Bug Obfuscator", -10, 10, 0},
		{"Bug Factory", -11, 12, -1},
		{"Bug Factory", -10, 9, 1},--
		{"Bug Factory", -9, 9, 0},--
		{"Bit Farmer", -11, 11, 0},--
		{"Patch Predicter", -8, 8, 0},--
		{"Bit Farmer", -9, 8, 1},--
		{"Bit Farmer", -10, 11, -1},--
		{"Patch Predicter", -4, 10, -6},--
		{"Patch Predicter", 2, -8, 6},--
		{"Memory Reader", -2, 2, 0},--
		{"Bug Obfuscator", -7, 11, -4},--
		{"Bug Obfuscator", -3, -1, 4},--
		{"Bug Obfuscator", 0, -4, 4},--
		{"Bug Cascade maker", 1, -5, 4},--
		{"Bug Cascade maker", -3, 7, -4},--
		{"Bug Obfuscator", -4, 8, -4},--
		{"Bug Obfuscator", 0, 0, 0},--
		{"Bug Cascade maker", -0, 1, -1},--
		{"Bug Cascade maker", 1, -2, 1},--
		{"Bug Factory", 1, -1, 0},--
		{"Bug Cascade maker", 2, 4, -6},--
		{"Bug Obfuscator", 1, 5, -6},--
		{"Bug Obfuscator", 7, -13, 6},--
		{"Bug Cascade maker", 8, -14, 6},--
		{"Memory Reader", 5, -5, 0},--
		{"Bug Activator", 9, -9, 0},--
		{"Bug Obfuscator", 8, -8, 0},--
		{"Bug Cascade maker", 7, -7, 0},--
		{"Bug Cascade maker", -4, 13, -9},--
		{"Bug Cascade maker", 5, -14, 9}}--